# BoomToknlab-Fixed

This is a cleaned-up version of the BoomToknlab project, separating Dockerfile changes from package.json updates and including the correct lockfile.

## How to Use

1. **Install Dependencies**  
   ```bash
   npm install
   ```

2. **Run Locally**  
   ```bash
   npm start
   ```
   The server starts on [http://localhost:3000](http://localhost:3000).

3. **Build Docker Image**  
   ```bash
   docker build -t boomtoknlab-fixed .
   ```

4. **Run Docker Container**  
   ```bash
   docker run -p 3000:3000 boomtoknlab-fixed
   ```

## Notes
- `.gitignore` excludes `node_modules` and other unnecessary files.
- `package-lock.json` is committed to ensure consistent dependencies.
- Feel free to update or rename this folder before zipping and pushing to your GitHub organization.
